#!/bin/bash

killall python


