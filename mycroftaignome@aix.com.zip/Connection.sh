#!/bin/bash

workon mycroft
cd /home/$USER/.local/share/gnome-shell/extensions/mycroftaignome@aix.com
python Connectmycroft.py
